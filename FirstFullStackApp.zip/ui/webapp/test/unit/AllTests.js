sap.ui.define([
	"testapp/ui/test/unit/controller/View1.controller"
], function () {
	"use strict";
});